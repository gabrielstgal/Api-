package com.nupex.api.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nupex.api.entidades.AvaliadorProjeto;

@Repository
public interface AvaliadorProjetoRepository extends JpaRepository<AvaliadorProjeto, Long> {}