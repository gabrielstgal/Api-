// Controlador de Projeto
package com.nupex.api.controladores;

import com.nupex.api.entidades.Projeto;
import com.nupex.api.repositorio.ProjetoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/projetos")
public class ProjetoControlador {

    @Autowired
    private ProjetoRepository projetoRepositorio;

    @GetMapping
    public List<Projeto> listarTodos() {
        return projetoRepositorio.findAll();
    }

    @PostMapping
    public Projeto criar(@RequestBody Projeto projeto) {
        return projetoRepositorio.save(projeto);
    }

    @PutMapping("/{id}")
    public Projeto atualizar(@PathVariable Long id, @RequestBody Projeto projetoAtualizado) {
        Projeto projeto = projetoRepositorio.findById(id).orElse(null);
        if (projeto != null) {
            projeto.setTitulo(projetoAtualizado.getTitulo());
            projeto.setDescricao(projetoAtualizado.getDescricao());
            projeto.setStatus(projetoAtualizado.getStatus());
            return projetoRepositorio.save(projeto);
        }
        return null;
    }
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        projetoRepositorio.deleteById(id);
    }
}

/* {
    "titulo": "Novo Projeto",
    "descricao": "Descrição do projeto",
    "dataSubmissao": "2024-12-08",
    "tipo": {
      "id": 1
    },
    "status": {
      "descricao": "INICIADO"
    },
    "usuario": {
      "id": 1
    }
  }

   */