package com.nupex.api.controladores;

import com.nupex.api.entidades.Usuario;
import com.nupex.api.repositorio.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/usuarios")
public class UsuarioControlador {

    @Autowired
    private UsuarioRepository usuarioRepositorio;

    // Listar todos os usuários
    @GetMapping
    public List<Usuario> listarTodos() {
        return usuarioRepositorio.findAll();
    }

    // Criar um novo usuário
    @PostMapping
    public String criar(@RequestBody Usuario usuario) {
        // Verifica se os dados obrigatórios estão presentes
        if (usuario.getNome() == null || usuario.getEmail() == null || usuario.getSenha() == null) {
            return "Dados incompletos. Nome, email e senha são obrigatórios."; // Mensagem de erro simples
        }
        usuarioRepositorio.save(usuario);
        return "Usuário criado com sucesso."; // Mensagem de sucesso
    }

    // Atualizar um usuário existente
    @PutMapping("/{id}")
    public String atualizar(@PathVariable Long id, @RequestBody Usuario usuarioAtualizado) {
        Optional<Usuario> usuarioOptional = usuarioRepositorio.findById(id);
        if (usuarioOptional.isPresent()) {
            Usuario usuario = usuarioOptional.get();
            usuario.setNome(usuarioAtualizado.getNome());
            usuario.setEmail(usuarioAtualizado.getEmail());
            usuario.setSenha(usuarioAtualizado.getSenha());
            usuarioRepositorio.save(usuario);
            return "Usuário atualizado com sucesso."; // Mensagem de sucesso
        } else {
            return "Usuário não encontrado."; // Mensagem de erro
        }
    }

    // Deletar um usuário
    @DeleteMapping("/{id}")
    public String deletar(@PathVariable Long id) {
        Optional<Usuario> usuarioOptional = usuarioRepositorio.findById(id);
        if (usuarioOptional.isPresent()) {
            usuarioRepositorio.deleteById(id);
            return "Usuário deletado com sucesso."; // Mensagem de sucesso
        } else {
            return "Usuário não encontrado."; // Mensagem de erro
        }
    }
}

/*
 * {
  "nome": "João Silva",
  "email": "joao.silva@example.com",
  "senha": "senha123",
  "tipoUsuario": "AVALIADOR"  // O valor de tipoUsuario deve ser um valor válido
}
 */