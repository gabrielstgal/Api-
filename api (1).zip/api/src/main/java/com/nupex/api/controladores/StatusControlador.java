package com.nupex.api.controladores;

import com.nupex.api.entidades.Status;
import com.nupex.api.repositorio.StatusRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/status")
public class StatusControlador {

    @Autowired
    private StatusRepository statusRepositorio;

    @GetMapping
    public List<Status> listarTodos() {
        return statusRepositorio.findAll();
    }

    @PostMapping
    public Status criar(@RequestBody Status status) {
        return statusRepositorio.save(status);
    }

    @PutMapping("/{id}")
    public Status atualizar(@PathVariable Long id, @RequestBody Status statusAtualizado) {
        Status status = statusRepositorio.findById(id).orElse(null);
        if (status != null) {
            status.setDescricao(statusAtualizado.getDescricao());
            return statusRepositorio.save(status);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        statusRepositorio.deleteById(id);
    }
}

/*{
    "descricao": "projeto iniciado"
}
     */ 