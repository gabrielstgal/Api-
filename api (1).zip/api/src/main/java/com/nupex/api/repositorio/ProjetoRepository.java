package com.nupex.api.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.nupex.api.entidades.Projeto;

@Repository
public interface ProjetoRepository extends JpaRepository<Projeto, Long> {}