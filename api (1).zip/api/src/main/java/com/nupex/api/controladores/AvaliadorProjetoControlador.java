package com.nupex.api.controladores;

import com.nupex.api.entidades.AvaliadorProjeto;
import com.nupex.api.repositorio.AvaliadorProjetoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/avaliador-projetos")
public class AvaliadorProjetoControlador {

    @Autowired
    private AvaliadorProjetoRepository avaliadorProjetoRepositorio;

    @GetMapping
    public List<AvaliadorProjeto> listarTodos() {
        return avaliadorProjetoRepositorio.findAll();
    }

    @PostMapping
    public AvaliadorProjeto criar(@RequestBody AvaliadorProjeto avaliadorProjeto) {
        return avaliadorProjetoRepositorio.save(avaliadorProjeto);
    }

    @PutMapping("/{id}")
    public AvaliadorProjeto atualizar(@PathVariable Long id, @RequestBody AvaliadorProjeto avaliadorProjetoAtualizado) {
        AvaliadorProjeto avaliadorProjeto = avaliadorProjetoRepositorio.findById(id).orElse(null);
        if (avaliadorProjeto != null) {
            avaliadorProjeto.setUsuario(avaliadorProjetoAtualizado.getUsuario());
            avaliadorProjeto.setProjeto(avaliadorProjetoAtualizado.getProjeto());
            avaliadorProjeto.setNota(avaliadorProjetoAtualizado.getNota());
            avaliadorProjeto.setComentario(avaliadorProjetoAtualizado.getComentario());
            return avaliadorProjetoRepositorio.save(avaliadorProjeto);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        avaliadorProjetoRepositorio.deleteById(id);
    }
}

/*{
    "usuario": {
        "id": 1
    },
    "projeto": {
        "id": 2
    },
    "nota": 4.5,
    "comentario": "Ótima execução do projeto"
} */