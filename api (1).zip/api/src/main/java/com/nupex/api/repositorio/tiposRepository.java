package com.nupex.api.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nupex.api.entidades.Tipos;

public interface tiposRepository extends JpaRepository<Tipos, Long> {
}