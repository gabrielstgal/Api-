// Controlador de Tipos
package com.nupex.api.controladores;

import com.nupex.api.entidades.Tipos;
import com.nupex.api.repositorio.tiposRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tipos")
public class TiposControlador {

    @Autowired
    private tiposRepository tiposRepositorio;

    @GetMapping
    public List<Tipos> listarTodos() {
        return tiposRepositorio.findAll();
    }

    @PostMapping
    public Tipos criar(@RequestBody Tipos tipo) {
        return tiposRepositorio.save(tipo);
    }

    @PutMapping("/{id}")
    public Tipos atualizar(@PathVariable Long id, @RequestBody Tipos tipoAtualizado) {
        Tipos tipo = tiposRepositorio.findById(id).orElse(null);
        if (tipo != null) {
            tipo.setNome(tipoAtualizado.getNome());
            return tiposRepositorio.save(tipo);
        }
        return null;
    }

    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        tiposRepositorio.deleteById(id);
    }
}

/* {
  "nome": "Pesquisa",
  "descricao": "Tipo relacionado a projetos de pesquisa"
} */