package com.nupex.api.repositorio;

import org.springframework.data.jpa.repository.JpaRepository;
import com.nupex.api.entidades.Usuario;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
}